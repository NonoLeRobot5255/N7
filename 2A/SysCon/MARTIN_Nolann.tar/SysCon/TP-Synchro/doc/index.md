Ces pages rassemblent un peu de documentation décrivant le noyau ManuX
(pour "Misérable Approximation de Noyau Un*X").
