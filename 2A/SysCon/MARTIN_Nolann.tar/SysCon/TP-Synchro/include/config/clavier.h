/*----------------------------------------------------------------------------*/
/* Gestion du clavier.                                                        */
/*----------------------------------------------------------------------------*/
#define MANUX_CLAVIER

/**
 * Le clavier est transmis vers la console active
 */
#define MANUX_CLAVIER_CONSOLE

