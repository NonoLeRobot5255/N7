/*----------------------------------------------------------------------------*/
/*      Implantation de RamDisk pour Manux.                                   */
/*                                                                            */
/*                                                       (C) Manu Chaput 2000 */
/*----------------------------------------------------------------------------*/
#include <manux/ramdisk.h>

#include <manux/console.h>

void initialiserRamDisk(uint32_t adresse, uint16_t tailleKo)
{

}
