/*----------------------------------------------------------------------------*/
/*      Implantation des sous-programmes de manipulation des dates et durées. */
/*                                                                            */
/*                                                  (C) Manu Chaput 2000-2021 */
/*----------------------------------------------------------------------------*/
#include <manux/temps.h>

